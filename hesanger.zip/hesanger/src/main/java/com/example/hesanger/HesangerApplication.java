package com.example.hesanger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HesangerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HesangerApplication.class, args);
	}

}
